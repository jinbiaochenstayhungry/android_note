//
//  main.m
//  OpenGLES_Ch12_1
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch12_1AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch12_1AppDelegate class]));
   }
}
