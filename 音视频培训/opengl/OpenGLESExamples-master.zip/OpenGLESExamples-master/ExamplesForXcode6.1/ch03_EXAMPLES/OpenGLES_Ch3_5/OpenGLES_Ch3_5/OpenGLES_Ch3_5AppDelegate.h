//
//  OpenGLES_Ch3_5AppDelegate.h
//  OpenGLES_Ch3_5
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch3_5AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
