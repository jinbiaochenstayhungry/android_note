//
//  main.m
//  OpenGLES_Ch3_5
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch3_5AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch3_5AppDelegate class]));
   }
}
