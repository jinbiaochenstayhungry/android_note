//
//  OpenGLES_Ch3_6AppDelegate.h
//  OpenGLES_Ch3_6
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch3_6AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
