//
//  OpenGLES_Ch7_3ViewController.h
//  OpenGLES_Ch7_3
//

#import <GLKit/GLKit.h>

@interface OpenGLES_Ch7_3ViewController : GLKViewController

- (IBAction)takeAngle0From:(UISlider *)sender;
- (IBAction)takeAngle1From:(UISlider *)sender;  
- (IBAction)takeAngle2From:(UISlider *)sender;  
- (IBAction)takeRigidSkinFrom:(UISwitch *)sender;

@end
