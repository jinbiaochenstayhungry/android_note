//
//  OpenGLES_Ch8_3AppDelegate.h
//  OpenGLES_Ch8_3
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch8_3AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
