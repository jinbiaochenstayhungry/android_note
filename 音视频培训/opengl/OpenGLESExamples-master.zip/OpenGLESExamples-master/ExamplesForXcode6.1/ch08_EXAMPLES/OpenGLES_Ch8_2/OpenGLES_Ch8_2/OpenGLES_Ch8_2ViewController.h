//
//  OpenGLES_Ch8_2ViewController.h
//  OpenGLES_Ch8_2
//

#import <GLKit/GLKit.h>

@interface OpenGLES_Ch8_2ViewController : GLKViewController

@end
