//
//  main.m
//  OpenGLES_Ch8_2
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch8_2AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch8_2AppDelegate class]));
   }
}
