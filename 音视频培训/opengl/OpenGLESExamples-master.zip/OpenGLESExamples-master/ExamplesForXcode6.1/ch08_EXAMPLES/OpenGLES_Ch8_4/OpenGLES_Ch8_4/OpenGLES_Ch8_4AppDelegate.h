//
//  OpenGLES_Ch8_4AppDelegate.h
//  OpenGLES_Ch8_4
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch8_4AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
