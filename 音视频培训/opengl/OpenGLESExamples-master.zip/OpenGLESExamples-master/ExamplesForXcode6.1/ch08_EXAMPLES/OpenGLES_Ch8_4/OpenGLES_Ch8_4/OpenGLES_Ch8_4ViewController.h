//
//  OpenGLES_Ch8_4ViewController.h
//  OpenGLES_Ch8_4
//

#import <GLKit/GLKit.h>

@interface OpenGLES_Ch8_4ViewController : GLKViewController

- (IBAction)takeShouldRenderSpherical:(UISwitch *)sender;

@end
