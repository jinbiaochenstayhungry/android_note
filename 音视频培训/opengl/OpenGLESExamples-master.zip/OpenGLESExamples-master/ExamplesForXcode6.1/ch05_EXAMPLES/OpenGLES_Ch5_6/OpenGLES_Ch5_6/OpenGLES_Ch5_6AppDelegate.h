//
//  OpenGLES_Ch5_6AppDelegate.h
//  OpenGLES_Ch5_6
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch5_6AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
