//
//  UtilityModelManager+skinning.h
//
//

#import "UtilityModelManager.h"

@interface UtilityModelManager (skinning)

- (void)prepareToDrawWithJointInfluence;

@end
