//
//  UtilityBillboardParticleManager+viewAdditions.h
//  
//

#import "UtilityBillboardParticleManager.h"

@interface UtilityBillboardParticleManager (viewAdditions)

- (void)drawWithCamera:(UtilityCamera *)aCamera;

@end
