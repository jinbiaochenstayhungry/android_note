//
//  UtilityModel+viewAdditions.h
// 
//

#import "UtilityModel.h"


@interface UtilityModel (viewAdditions)

- (void)draw;

@end
