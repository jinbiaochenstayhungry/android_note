//
//  OpenGLES_Ch6_5AppDelegate.h
//  OpenGLES_Ch6_5
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch6_5AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
