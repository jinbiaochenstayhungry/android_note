//
//  SceneCanLightModel.h
// 
//

#import "SceneModel.h"

@interface SceneCanLightModel : SceneModel

@end
