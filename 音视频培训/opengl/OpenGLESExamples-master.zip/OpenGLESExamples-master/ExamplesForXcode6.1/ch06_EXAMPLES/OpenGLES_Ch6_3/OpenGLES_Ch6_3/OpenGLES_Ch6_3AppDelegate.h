//
//  OpenGLES_Ch6_3AppDelegate.h
//  OpenGLES_Ch6_3
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch6_3AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
