//
//  OpenGLES_Ch6_4AppDelegate.h
//  OpenGLES_Ch6_4
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch6_4AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
