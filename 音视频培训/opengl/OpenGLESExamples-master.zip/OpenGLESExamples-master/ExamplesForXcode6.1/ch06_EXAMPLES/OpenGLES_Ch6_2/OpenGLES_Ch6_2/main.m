//
//  main.m
//  OpenGLES_Ch6_2
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch6_2AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch6_2AppDelegate class]));
   }
}
