//
//  TEModelPlacement.m
//  TerrainEditor
//

#import "TEModelPlacement.h"
#import "TETerrain.h"


@implementation TEModelPlacement

@dynamic angle;
@dynamic modelName;
@dynamic positionX;
@dynamic positionY;
@dynamic positionZ;
@dynamic index;
@dynamic terrain;

@end
