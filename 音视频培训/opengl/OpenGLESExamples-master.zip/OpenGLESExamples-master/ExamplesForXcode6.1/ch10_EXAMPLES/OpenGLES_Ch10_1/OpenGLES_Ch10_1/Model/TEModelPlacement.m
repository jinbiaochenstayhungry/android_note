//
//  TEModelPlacement.m
//

#import "TEModelPlacement.h"
#import "TETerrain.h"


@implementation TEModelPlacement

@dynamic angle;
@dynamic index;
@dynamic modelName;
@dynamic positionX;
@dynamic positionY;
@dynamic positionZ;
@dynamic terrain;

@end
